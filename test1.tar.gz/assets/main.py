import pygame
import pygame.mixer
from pygame.locals import*
import sys
import os
import random
import asyncio

SCREEN=Rect((0,0,640,480))
#imageデータのロード関数(サイズ変更対応可)
def load_image(filename,size=None):
    temp=pygame.image.load("images/"+filename)
    return temp if size==None else pygame.transform.scale(temp,size)
#soundデータのロード関数
def load_sound(sound):
    return pygame.mixer.Sound("music/"+sound)

"""登場する人/物/背景のクラスの定義"""

class Background:
    """背景"""
    def __init__(self,majo):
        self.majo=majo
        self.sky_image=load_image("bg_natural_sky.jpg",SCREEN.size)
        self.mount_image=load_image("bg_natural_mount_800x800.png")
        self.mount_rect=self.mount_image.get_rect()
        self.ground_image=pygame.Surface((SCREEN.width,20))
        self.ground_image.fill((0,128,64))
        self.ground_rect=self.ground_image.get_rect()
        self.ground_rect.bottom=SCREEN.bottom
        
    def update(self):
        #魔女が生きていればその位置に合わせる
        if self.majo and self.majo.alive():
            self.mount_image_x=(self.mount_rect.width-SCREEN.width)/SCREEN.width*self.majo.rect.centerx
        else:
            self.mount_image_x=0
        
    def draw(self,screen):
        screen.blit(self.sky_image,SCREEN)
        screen.blit(self.mount_image,(-self.mount_image_x,-118))
        screen.blit(self.ground_image,self.ground_rect)
        

class Majo(pygame.sprite.Sprite):
    """魔女"""
    IMAGE_WIDTH,IMAGE_HEIGHT=32,32
    LEFT,RIGHT=1,2
    SPEED=5
    IMAGE_NUMBER=3
    life=5
    MINUS_LIFE=1
    
    def __init__(self):
        pygame.sprite.Sprite.__init__(self,self.containers)
        self.images=load_image("majo.png")
        self.image_column=Majo.LEFT
        self.image_row=0
        self.image=self.images.subsurface(
            (0,0,Majo.IMAGE_WIDTH,Majo.IMAGE_HEIGHT)
        )
        self.rect=Rect((0,0,Majo.IMAGE_WIDTH,Majo.IMAGE_HEIGHT))
        self.rect.centerx=SCREEN.centerx
        self.rect.bottom=SCREEN.bottom-20
        
    def set_init(self):
        Majo.life=3
        Majo.score.set_image("Majo:"+"@"*Majo.life)
        
    def move_left(self):
        self.rect.move_ip(-Majo.SPEED,0)
        self.image_row=Majo.LEFT
        self.move()
        
    def move_right(self):
        self.rect.move_ip(Majo.SPEED,0)
        self.image_row=Majo.RIGHT    
        self.move()
        
    def move(self):
        self.rect.clamp_ip(SCREEN)
        #image_columnに順次0,1,2を入力する
        self.image_column=(self.image_column+1)%Majo.IMAGE_NUMBER
        self.image=self.images.subsurface(
            (self.image_column*Majo.IMAGE_WIDTH,self.image_row*Majo.IMAGE_HEIGHT,Majo.IMAGE_WIDTH,Majo.IMAGE_HEIGHT)
        )
                
    def update(self):
        pass
    
    def update_life(self,pt):
        Majo.life+=pt
        if Majo.life<0:
            Majo.life=0
        Majo.score.set_image("Majo:"+"@"*Majo.life)            

class Beam(pygame.sprite.Sprite):
    """魔女のビーム"""
    SPEED=6
    counter=0
    #爆発アニメ
    EXP_IMAGE_WIDTH,EXP_IMAGE_HEIGHT=120,120
    EXP_IMAGE_NUMBER=5
    EXP_SHIFT_INTERVAL=5
     
    def __init__(self,majo):
        pygame.sprite.Sprite.__init__(self,self.containers)
        #self.majo=majo
        self.rect=self.image.get_rect()
        #self.rect.centerx=self.majo.rect.centerx
        self.rect.centerx=majo.rect.centerx
        #self.rect.bottom=self.majo.rect.top
        self.rect.bottom=majo.rect.top
        
        Beam.counter+=1
        Beam.sound.play()
                
    def update(self):
        self.rect.top-=Beam.SPEED
        if self.rect.top<SCREEN.top:
            Beam.counter-=1
            self.kill()
                        

class Ufo(pygame.sprite.Sprite):
    """Ufo"""
    IMAGE_WIDTH,IMAGE_HEIGHT=64,28
    START=SCREEN.width/3,30
    SPEED=5
    LEFT,RIGHT=0,1
    BOMB_PROB=0.015
    MINUS_POINT=5
    point=60
    #爆発アニメ
    EXP_IMAGE_WIDTH,EXP_IMAGE_HEIGHT=320,120
    EXP_IMAGE_NUMBER=8
    EXP_SHIFT_INTERVAL=10
                    
    
    def __init__(self):
        pygame.sprite.Sprite.__init__(self,self.containers)
        self.image=Ufo.images.subsurface(
            Ufo.LEFT,0,Ufo.IMAGE_WIDTH,Ufo.IMAGE_HEIGHT
            )
        self.rect=self.image.get_rect()
        self.rect.midtop=Ufo.START
        self.speed=Ufo.SPEED
        self.dir=Ufo.LEFT
        
    def set_init(self):
        Ufo.point=30
        Ufo.score.set_image("UFO:"+str(Ufo.point))
        
    def update_score(self,pt):
        Ufo.point+=pt
        if Ufo.point<0:
            Ufo.point=0
        Ufo.score.set_image("UFO:"+str(Ufo.point))
        
    def update(self):
        self.rect.move_ip(self.speed,0)
        if self.rect.left<=SCREEN.left or self.rect.right>=SCREEN.right:
            self.speed=-self.speed
        self.rect.clamp_ip(SCREEN)
        #speedが+の時はufoはLEFT,speedが-の時はufoはRIGHT
        self.dir=Ufo.LEFT if self.speed>0 else Ufo.RIGHT
        self.image=Ufo.images.subsurface(
            self.dir*Ufo.IMAGE_WIDTH,0,Ufo.IMAGE_WIDTH,Ufo.IMAGE_HEIGHT
        )
        #乱数が しきい値BOMB_PROBが0.015未満の時bombを投下する
        if random.random()<Ufo.BOMB_PROB:
            Bomb(self)
            
        """Ufoの爆発シーン"""
        if Ufo.point<=0:
            Explosion(
                Ufo.exp_images,
                self.rect.center,
                (Ufo.EXP_IMAGE_WIDTH,Ufo.EXP_IMAGE_HEIGHT),
                Ufo.EXP_IMAGE_NUMBER,
                Ufo.EXP_SHIFT_INTERVAL,
                Ufo.exp_sound
            )
            self.kill()
            return
            
class Explosion(pygame.sprite.Sprite):
    """爆発アニメーション"""
    
    def __init__(self,
                images, #画像(複数画像より構成)
                start_position, #爆発開始位置
                image_size, #単体画像のサイズ
                max_image_number, #画像の構成数
                max_shift_interval, #画像の切替間隔
                exp_sound #爆発時の音 
                ):
            pygame.sprite.Sprite.__init__(self,self.containers)
            self.images=images
            self.images_rect=self.images.get_rect()
            self.max_image_number=max_image_number
            self.image_number=0
            self.max_shift_interval=max_shift_interval
            self.shift_interval=0
            self.sizex,self.sizey=image_size
            #image構成画像の横長or縦長の判別
            if self.images_rect.width>self.images_rect.height:
                #imagesは横長の画像
                self.image=self.images.subsurface(
                    (self.image_number*self.sizex,0,self.sizex,self.sizey)
                )
            else:
                self.image=self.images.subsurface(
                    (0,self.image_number*self.sizey,self.sizex,self.sizey)
                )
            
            self.rect=self.image.get_rect()
            self.rect.center=start_position
            exp_sound.play()

    def update(self):
            self.shift_interval=(self.shift_interval+1)%self.max_shift_interval
            if self.shift_interval==0:
                self.image_number+=1
                if self.image_number==self.max_image_number:
                    self.image_number=0
                    self.kill()
                    return
            if self.images_rect.width>self.images_rect.height:
                #imagesは横長の画像
                self.image=self.images.subsurface(
                    (self.image_number*self.sizex,0,self.sizex,self.sizey)
                )
            else:
                self.image=self.images.subsurface(
                    (0,self.image_number*self.sizey,self.sizex,self.sizey)
                )        
    
    
class Bomb(pygame.sprite.Sprite):
    """Ufoが落とす爆弾bomb"""
    IMAGE_ROW,IMAGE_COLUMN=4,3
    IMAGE_WIDTH,IMAGE_HEIGHT=64,112
    SPEED=5
    #爆発アニメ
    EXP_IMAGE_WIDTH,EXP_IMAGE_HEIGHT=120,120
    EXP_IMAGE_NUMBER=7
    EXP_SHIFT_INTERVAL=5
    
    def __init__(self, ufo):
        pygame.sprite.Sprite.__init__(self,self.containers)
        self.image_row=int(random.random()*Bomb.IMAGE_ROW)
        self.image_column=0
        self.image=Bomb.images.subsurface(
            self.image_column*Bomb.IMAGE_WIDTH,self.image_row*Bomb.IMAGE_HEIGHT,Bomb.IMAGE_WIDTH,Bomb.IMAGE_HEIGHT
        )
        self.rect=self.image.get_rect()
        self.rect.midtop=ufo.rect.midbottom
        
    def update(self):
        self.rect.move_ip(0,Bomb.SPEED)
        if self.rect.bottom>SCREEN.bottom:
            Explosion(
                Bomb.exp_images,
                self.rect.center,
                (Bomb.EXP_IMAGE_WIDTH,Bomb.EXP_IMAGE_HEIGHT),
                Bomb.EXP_IMAGE_NUMBER,
                Bomb.EXP_SHIFT_INTERVAL,
                Bomb.exp_sound
            )
            self.kill()
            return
        self.image_column=(self.image_column+1)%Bomb.IMAGE_COLUMN
        self.image=Bomb.images.subsurface(
            self.image_column*Bomb.IMAGE_WIDTH,self.image_row*Bomb.IMAGE_HEIGHT,Bomb.IMAGE_WIDTH,Bomb.IMAGE_HEIGHT
        )

class Point(pygame.sprite.Sprite):
    """マイナスポイントを表示"""
    FONT_SIZE=32
    RED=(255,0,0)
    DISPLAY_INTERVAL=50
    
    def __init__(self,point,start_position):
        pygame.sprite.Sprite.__init__(self,self.containers)
        self.point=point
        self.font=pygame.font.SysFont(None,Point.FONT_SIZE)
        self.image=self.font.render(
            "-"+str(self.point),False,Point.RED
        )
        self.rect=self.image.get_rect()
        self.rect.center=start_position
        self.display_interval=0
        
    def update(self):
        self.display_interval+=1
        if self.display_interval==Point.DISPLAY_INTERVAL:
            self.kill()
            return

class Score(pygame.sprite.Sprite):
    """スコア表示"""
    FONT_SIZE=28
    BLUE=(0,0,255)
    RED=(255,0,0)
    
    def __init__(self,text_img,color,position):
        pygame.sprite.Sprite.__init__(self,self.containers)
        self.font=pygame.font.SysFont(None,Score.FONT_SIZE)
        self.color=color
        self.image=self.font.render(text_img,False,self.color)
        self.rect=self.image.get_rect().move(position)
    
    def set_image(self,text_img):
        self.image=self.font.render(text_img,False,self.color)    
    def update(self):
        pass

def collision_detection(majo,ufo,beam_g,bomb_g,):  
    """Beam/Ufoとの衝突判定"""
    if ufo and ufo.alive():
        beam_collided=pygame.sprite.spritecollide(ufo,beam_g,True)    
        if beam_collided:
            Explosion(
                Beam.exp_images,
                beam_collided[0].rect.center,
                (Beam.EXP_IMAGE_WIDTH,Beam.EXP_IMAGE_HEIGHT),
                Beam.EXP_IMAGE_NUMBER,
                Beam.EXP_SHIFT_INTERVAL,
                Beam.exp_sound    
            )
            if Beam.counter>0:
                Beam.counter-=1
            Point(Ufo.MINUS_POINT,ufo.rect.center)
            ufo.update_score(-Ufo.MINUS_POINT)
            
    """BeamとBombとの衝突判定"""
    group_collided=pygame.sprite.groupcollide(
        bomb_g,beam_g,True,True)
    if group_collided:
        for bomb,beams in group_collided.items():
            for beam in beams:  
                Explosion(
                    Beam.exp_images,
                    bomb.rect.center,
                    (Beam.EXP_IMAGE_WIDTH,Beam.EXP_IMAGE_HEIGHT),
                    Beam.EXP_IMAGE_NUMBER,
                    Beam.EXP_SHIFT_INTERVAL,
                    Beam.exp02_sound    
                )        
        if Beam.counter>0:
            Beam.counter-=1
    
    """MajoとBombとの衝突判定"""
    if majo and majo.alive():
        bomb_collided=pygame.sprite.spritecollide(majo,bomb_g,True)
        if bomb_collided:
            Explosion(
                Bomb.exp_images,
                majo.rect.center,
                (Bomb.EXP_IMAGE_WIDTH,Bomb.EXP_IMAGE_HEIGHT),
                Bomb.EXP_IMAGE_NUMBER,
                Bomb.EXP_SHIFT_INTERVAL,
                Bomb.exp_sound    
            )        
            majo.update_life(-1)
            Point(Majo.MINUS_LIFE,majo.rect.center)
            if Majo.life<=0:
                majo.kill()
            
                                                    
async def main():    
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    """初期設定"""
    #画面の初期設定
    pygame.init()
    screen=pygame.display.set_mode(SCREEN.size)
    pygame.display.set_caption("Animation")
    
    INIT,PLAY,CLEAR,GAMEOVER=1,2,3,4
    game_status=INIT
    
    #時間管理
    clock=pygame.time.Clock()
    
    """Sprite登録"""
    #sprite.groupの作成
    group=pygame.sprite.RenderUpdates()
    bomb_g=pygame.sprite.Group()
    beam_g=pygame.sprite.Group()
    #containersクラスメンバーにsprite.groupを登録
    Majo.containers=group
    Beam.containers=group,beam_g
    Ufo.containers=group
    Bomb.containers=group,bomb_g
    Explosion.containers=group
    Point.containers=group
    Score.containers=group
    
    """登場する人/物/背景の作成(リソースのロード)"""
    Beam.sound=load_sound("shot.ogg")
    Beam.image=load_image("majo_beam.png")
    Ufo.images=load_image("ufo.png",(128,28))
    Ufo.exp_images=load_image("ufo_fire.png",(320,960))
    Ufo.exp_sound=load_sound("explosion.ogg")
    Bomb.images=load_image("ufo_bomb.png")
    Bomb.exp_images=load_image("bomb_fire.png")
    Bomb.exp_sound=load_sound("damage.ogg")
    Beam.exp_images=load_image("beam_fire.png")
    Beam.exp_sound=load_sound("explosion02.ogg")
    Beam.exp02_sound=load_sound("damage.ogg")
    
    title_msg={
        INIT:load_image("game_start.png",(300,200)),
        GAMEOVER:load_image("gameover_r.png",(400,300)),
        CLEAR:load_image("gameover_c.png",(400,300))
    }
    opening_sound=load_sound("prologue.ogg")
    opening_sound.set_volume(0.4)
    opening_sound.play(-1)
    play_sound=load_sound("maou_bgm_neorock83.ogg")
    play_sound.set_volume(0.4)
    
    
    Majo.score=Score("Majo:"+"@"*Majo.life,Score.RED,(SCREEN.right-150,5))
    Ufo.score=Score("UFO:"+str(Ufo.point),Score.BLUE,(100,5))
    
    majo=Majo()
    ufo=None
    bg_img=Background(majo)
    #ufo=Ufo()
    
    while True:
        
        """画面(screen)をクリア"""
        screen.fill((0,0,0))
        
        """ゲームに登場する人/物/背景の位置Update"""
        bg_img.update()
        group.update()
        #majo.update()
        
        """画面(screen)に登場する人/物/背景を描画"""
        bg_img.draw(screen)
        group.draw(screen)
        
        if game_status!=PLAY:
            screen.blit(title_msg[game_status],(100,150))
        """衝突判定"""
        if game_status==PLAY:
            collision_detection(majo,ufo,beam_g,bomb_g)
        
        """ゲームステータスの変更"""
        if game_status==PLAY and Majo.life<=0:
            game_status=GAMEOVER
            play_sound.stop()
            opening_sound.play(-1)
        if game_status==PLAY and Ufo.point<=0:
            game_status=CLEAR
            play_sound.stop()
            opening_sound.play(-1)
            
        """画面(screen)の実表示"""
        pygame.display.update()
                
        
        """イベント処理"""
        for event in pygame.event.get():
            if event.type == QUIT:
                pygame.quit()
                sys.exit()
            elif event.type==KEYDOWN:
                if event.key==K_SPACE and game_status==PLAY:
                    #majoが生きている時のみbeamを発射
                    if majo.alive() and Beam.counter<5:
                        Beam(majo)
                elif event.key==K_SPACE and game_status==INIT:
                    game_status=PLAY
                    ufo=Ufo()
                    opening_sound.stop()
                    play_sound.play(-1)
                elif event.key==K_c and game_status==CLEAR:
                    game_status=PLAY
                    if ufo: ufo.kill()
                    ufo=Ufo()
                    ufo.set_init()
                    opening_sound.stop()
                    play_sound.play(-1)
                elif event.key==K_r and game_status==GAMEOVER:
                    game_status=PLAY
                    if ufo: ufo.kill()
                    if majo: majo.kill()
                    ufo=Ufo()
                    majo=Majo()
                    #Backgroundインスタンスに新しいMajoを登録
                    bg_img.majo=majo 
                    ufo.set_init()
                    majo.set_init()
                    opening_sound.stop()
                    play_sound.play(-1)
        """プレイヤー操作(PLAY中且つ魔女が生きている場合のみ移動)"""
        if game_status==PLAY and majo.alive():        
            pressed_keys=pygame.key.get_pressed()
            #押されているキーに応じて画像を移動
            if pressed_keys[K_LEFT]:
                majo.move_left()
            elif pressed_keys[K_RIGHT]:
                majo.move_right()
                
        """描画スピードの調整(FPS)"""
        clock.tick(60)
        await asyncio.sleep(0)
        
if __name__ == "__main__":
    asyncio.run(main())